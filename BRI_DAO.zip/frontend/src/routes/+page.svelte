<script>
    let name = 'BHRIGU DAO';
</script>

<h1>Hello {name}!</h1>
<p>Welcome to your ICP frontend.</p>