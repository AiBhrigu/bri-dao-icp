# Frontend
SvelteKit project.  
Commands:  
- npm install  
- npm run dev