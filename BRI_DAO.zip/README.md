# BRI DAO — Internet Computer Project

## Backend
`dfx deploy bri-token-backend`

## Frontend
`npm install`
`npm run dev`

## Governance Module
`dfx deploy governance-module`