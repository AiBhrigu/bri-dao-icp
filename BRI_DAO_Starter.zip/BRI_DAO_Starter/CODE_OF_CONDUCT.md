# Code of Conduct

- Be respectful  
- No hate speech  
- Keep discussions constructive  
- Respect diverse ideas and open collaboration
