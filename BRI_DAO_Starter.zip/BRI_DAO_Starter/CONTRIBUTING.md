# Contribution Guide

✅ Fork the repo  
✅ Make your edits  
✅ Create a Pull Request  
✅ Respect the coding & communication style.

All edits must sync with `docs/Whitepaper.md` and `Changelog.md`.

Language: English & Russian are welcome.
